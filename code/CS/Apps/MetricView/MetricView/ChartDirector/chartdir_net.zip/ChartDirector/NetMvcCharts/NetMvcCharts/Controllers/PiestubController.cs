using System.Web.Mvc;

namespace NetMvcCharts.Controllers
{
    public class PiestubController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}
