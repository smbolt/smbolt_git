using System.Web.Mvc;

namespace NetMvcCharts.Controllers
{
    public class XystubController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}
